from mfa import generate_totp_secret, verify_totp, generate_recovery_codes, hash_recovery_code

def test_totp_valid_code():
    import pyotp
    secret = generate_totp_secret()
    code = pyotp.TOTP(secret).now()
    assert verify_totp(secret, code) is True

def test_totp_invalid_code():
    secret = generate_totp_secret()
    assert verify_totp(secret, "000000") is False

def test_recovery_codes_are_unique():
    codes = generate_recovery_codes(8)
    assert len(codes) == len(set(codes)) == 8

def test_recovery_hash_is_deterministic():
    assert hash_recovery_code("ABC123") == hash_recovery_code("ABC123")
    assert hash_recovery_code("ABC123") != hash_recovery_code("ABC124")
